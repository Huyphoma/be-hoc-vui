from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.database import Base, engine, SessionLocal
from app.routers import auth, subjects, lessons, questions, cart, activities
from app.seeds import seed_initial_content

Base.metadata.create_all(bind=engine)

# Seed dữ liệu mẫu nếu DB đang trống
with SessionLocal() as db:
    seed_initial_content(db)


app = FastAPI(
    title="Be Hoc Vui API",
    version="1.0.0",
    description="Backend API cho ứng dụng Bé Học Vui"
)

# CORS cho phép FE gọi API
origins = ["*"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router, prefix="/auth", tags=["Auth"])
app.include_router(subjects.router, prefix="/subjects", tags=["Subjects"])
app.include_router(lessons.router, prefix="/lessons", tags=["Lessons"])
app.include_router(questions.router, prefix="/questions", tags=["Questions"])
app.include_router(cart.router, prefix="/cart", tags=["Cart"])
app.include_router(activities.router, prefix="/activities", tags=["Activities"])

@app.get("/")
def read_root():
    return {"message": "Be Hoc Vui API is running"}
