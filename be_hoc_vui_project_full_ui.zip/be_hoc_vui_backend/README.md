# Bé Học Vui Backend (FastAPI)

Các endpoint chính:

- `GET /` - kiểm tra server
- `POST /auth/register` - đăng ký
- `POST /auth/token` - đăng nhập (OAuth2 password)
- `GET /auth/me` - thông tin user

- `GET /subjects/` - danh sách chủ đề
- `POST /subjects/` - tạo chủ đề

- `GET /lessons/?subject_id=` - danh sách bài học theo chủ đề
- `POST /lessons/` - tạo bài học

- `GET /questions/?lesson_id=` - câu hỏi theo bài
- `POST /questions/` - tạo câu hỏi

- `GET /cart/items` - giỏ hàng của user
- `POST /cart/items` - thêm vào giỏ
- `DELETE /cart/items/{id}` - xoá khỏi giỏ

- `GET /activities/?lesson_id=` - danh sách activity theo bài (video/game/quiz)
- `POST /activities/` - tạo activity mới
