from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app import models, schemas
from app.database import get_db
from app.deps import get_current_user

router = APIRouter()


@router.get("/", response_model=List[schemas.Lesson])
def list_lessons(
    subject_id: Optional[int] = None,
    db: Session = Depends(get_db),
):
    query = db.query(models.Lesson)
    if subject_id is not None:
        query = query.filter(models.Lesson.subject_id == subject_id)
    return query.order_by(models.Lesson.order_index, models.Lesson.id).all()


@router.post("/", response_model=schemas.Lesson)
def create_lesson(
    lesson_in: schemas.LessonCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    subject = db.query(models.Subject).get(lesson_in.subject_id)
    if not subject:
        raise HTTPException(status_code=404, detail="Subject not found")

    lesson = models.Lesson(**lesson_in.dict())
    db.add(lesson)
    db.commit()
    db.refresh(lesson)
    return lesson


@router.get("/{lesson_id}", response_model=schemas.Lesson)
def get_lesson(lesson_id: int, db: Session = Depends(get_db)):
    lesson = db.query(models.Lesson).get(lesson_id)
    if not lesson:
        raise HTTPException(status_code=404, detail="Lesson not found")
    return lesson
