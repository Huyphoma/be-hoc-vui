from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app import models, schemas
from app.database import get_db
from app.deps import get_current_user

router = APIRouter()


@router.get("/", response_model=List[schemas.Subject])
def list_subjects(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    return (
        db.query(models.Subject)
        .order_by(models.Subject.order_index, models.Subject.id)
        .offset(skip)
        .limit(limit)
        .all()
    )


@router.post("/", response_model=schemas.Subject)
def create_subject(
    subject_in: schemas.SubjectCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    subject = models.Subject(**subject_in.dict())
    db.add(subject)
    db.commit()
    db.refresh(subject)
    return subject


@router.get("/{subject_id}", response_model=schemas.Subject)
def get_subject(subject_id: int, db: Session = Depends(get_db)):
    subject = db.query(models.Subject).get(subject_id)
    if not subject:
        raise HTTPException(status_code=404, detail="Subject not found")
    return subject
