from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app import models, schemas
from app.database import get_db
from app.deps import get_current_user

router = APIRouter()


@router.get("/", response_model=List[schemas.Question])
def list_questions(
    lesson_id: Optional[int] = None,
    db: Session = Depends(get_db),
):
    query = db.query(models.Question)
    if lesson_id is not None:
        query = query.filter(models.Question.lesson_id == lesson_id)
    return query.order_by(models.Question.id).all()


@router.post("/", response_model=schemas.Question)
def create_question(
    question_in: schemas.QuestionCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    lesson = db.query(models.Lesson).get(question_in.lesson_id)
    if not lesson:
        raise HTTPException(status_code=404, detail="Lesson not found")

    question = models.Question(**question_in.dict())
    db.add(question)
    db.commit()
    db.refresh(question)
    return question


@router.get("/{question_id}", response_model=schemas.Question)
def get_question(question_id: int, db: Session = Depends(get_db)):
    question = db.query(models.Question).get(question_id)
    if not question:
        raise HTTPException(status_code=404, detail="Question not found")
    return question
