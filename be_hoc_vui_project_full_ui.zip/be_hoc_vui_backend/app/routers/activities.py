from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app import models, schemas
from app.database import get_db
from app.deps import get_current_user

router = APIRouter()


@router.get("/", response_model=List[schemas.Activity])
def list_activities(
    lesson_id: Optional[int] = None,
    db: Session = Depends(get_db),
):
    query = db.query(models.Activity)
    if lesson_id is not None:
        query = query.filter(models.Activity.lesson_id == lesson_id)
    return query.order_by(models.Activity.order_index, models.Activity.id).all()


@router.post("/", response_model=schemas.Activity)
def create_activity(
    activity_in: schemas.ActivityCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    lesson = db.query(models.Lesson).get(activity_in.lesson_id)
    if not lesson:
        raise HTTPException(status_code=404, detail="Lesson not found")

    activity = models.Activity(**activity_in.dict())
    db.add(activity)
    db.commit()
    db.refresh(activity)
    return activity


@router.get("/{activity_id}", response_model=schemas.Activity)
def get_activity(
    activity_id: int,
    db: Session = Depends(get_db),
):
    activity = db.query(models.Activity).get(activity_id)
    if not activity:
        raise HTTPException(status_code=404, detail="Activity not found")
    return activity


@router.put("/{activity_id}", response_model=schemas.Activity)
def update_activity(
    activity_id: int,
    activity_in: schemas.ActivityCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    activity = db.query(models.Activity).get(activity_id)
    if not activity:
        raise HTTPException(status_code=404, detail="Activity not found")

    for field, value in activity_in.dict().items():
        setattr(activity, field, value)

    db.add(activity)
    db.commit()
    db.refresh(activity)
    return activity


@router.delete("/{activity_id}")
def delete_activity(
    activity_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    activity = db.query(models.Activity).get(activity_id)
    if not activity:
        raise HTTPException(status_code=404, detail="Activity not found")

    db.delete(activity)
    db.commit()
    return {"ok": True}
