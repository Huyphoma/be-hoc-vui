from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, Float, Text
from sqlalchemy.orm import relationship

from .database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    full_name = Column(String, nullable=True)
    hashed_password = Column(String, nullable=False)
    is_active = Column(Boolean, default=True)

    cart_items = relationship("CartItem", back_populates="user")


class Subject(Base):
    __tablename__ = "subjects"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    image_url = Column(String, nullable=True)
    order_index = Column(Integer, default=0)

    lessons = relationship("Lesson", back_populates="subject")


class Lesson(Base):
    __tablename__ = "lessons"

    id = Column(Integer, primary_key=True, index=True)
    subject_id = Column(Integer, ForeignKey("subjects.id"), nullable=False)
    title = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    order_index = Column(Integer, default=0)
    video_url = Column(String, nullable=True)
    audio_url = Column(String, nullable=True)

    subject = relationship("Subject", back_populates="lessons")
    questions = relationship("Question", back_populates="lesson")
    activities = relationship("Activity", back_populates="lesson")


class Question(Base):
    __tablename__ = "questions"

    id = Column(Integer, primary_key=True, index=True)
    lesson_id = Column(Integer, ForeignKey("lessons.id"), nullable=False)
    text = Column(Text, nullable=False)
    question_type = Column(String, default="multiple_choice")  # multiple_choice, true_false, typing
    options_json = Column(Text, nullable=True)  # Lưu JSON string các đáp án
    correct_answer = Column(String, nullable=True)
    explanation = Column(Text, nullable=True)

    lesson = relationship("Lesson", back_populates="questions")


class Activity(Base):
    __tablename__ = "activities"

    id = Column(Integer, primary_key=True, index=True)
    lesson_id = Column(Integer, ForeignKey("lessons.id"), nullable=False)
    title = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    activity_type = Column(String, nullable=False, default="video")  # video, game, quiz, story...
    order_index = Column(Integer, default=0)
    content_url = Column(String, nullable=True)  # link video, audio, hình... nếu có
    config_json = Column(Text, nullable=True)  # cấu hình chi tiết dạng JSON (tùy loại activity)

    lesson = relationship("Lesson", back_populates="activities")


class Product(Base):
    __tablename__ = "products"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    price = Column(Float, nullable=False)
    is_active = Column(Boolean, default=True)

    cart_items = relationship("CartItem", back_populates="product")


class CartItem(Base):
    __tablename__ = "cart_items"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False)
    quantity = Column(Integer, default=1)
    status = Column(String, default="in_cart")  # in_cart, ordered

    user = relationship("User", back_populates="cart_items")
    product = relationship("Product", back_populates="cart_items")
