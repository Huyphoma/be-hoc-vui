from typing import Optional
from pydantic import BaseModel, EmailStr


# =========================
# User schemas
# =========================
class UserBase(BaseModel):
    email: EmailStr
    full_name: Optional[str] = None


class UserCreate(UserBase):
    password: str


class User(UserBase):
    id: int
    is_active: bool

    class Config:
        orm_mode = True


# =========================
# Subject / Lesson / Question
# =========================
class SubjectBase(BaseModel):
    title: str
    description: Optional[str] = None
    image_url: Optional[str] = None
    order_index: int = 0


class SubjectCreate(SubjectBase):
    pass


class Subject(SubjectBase):
    id: int

    class Config:
        orm_mode = True


class LessonBase(BaseModel):
    subject_id: int
    title: str
    description: Optional[str] = None
    order_index: int = 0
    video_url: Optional[str] = None
    audio_url: Optional[str] = None


class LessonCreate(LessonBase):
    pass


class Lesson(LessonBase):
    id: int

    class Config:
        orm_mode = True


class QuestionBase(BaseModel):
    lesson_id: int
    text: str
    question_type: str = "multiple_choice"
    options_json: Optional[str] = None
    correct_answer: Optional[str] = None
    explanation: Optional[str] = None


class QuestionCreate(QuestionBase):
    pass


class Question(QuestionBase):
    id: int

    class Config:
        orm_mode = True


# =========================
# Activity
# =========================
class ActivityBase(BaseModel):
    lesson_id: int
    title: str
    description: Optional[str] = None
    activity_type: str = "video"  # video, game, quiz, story...
    order_index: int = 0
    content_url: Optional[str] = None
    config_json: Optional[str] = None


class ActivityCreate(ActivityBase):
    pass


class Activity(ActivityBase):
    id: int

    class Config:
        orm_mode = True


# =========================
# Product & Cart
# =========================
class ProductBase(BaseModel):
    title: str
    description: Optional[str] = None
    price: float
    is_active: bool = True


class ProductCreate(ProductBase):
    pass


class Product(ProductBase):
    id: int

    class Config:
        orm_mode = True


class CartItemBase(BaseModel):
    product_id: int
    quantity: int = 1


class CartItemCreate(CartItemBase):
    pass


class CartItem(CartItemBase):
    id: int
    status: str
    product: Product

    class Config:
        orm_mode = True


# =========================
# Auth schemas
# =========================
class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class TokenData(BaseModel):
    email: Optional[str] = None
