from sqlalchemy.orm import Session

from . import models


def seed_initial_content(db: Session) -> None:
    """Seed một ít dữ liệu mẫu cho Bé Học Vui nếu DB đang trống.

    Gồm:
    - Subject: Ngôn ngữ, Toán tư duy, Kỹ năng sống
    - Mỗi subject có vài lesson
    - Mỗi lesson có 1-2 activity demo
    """
    if db.query(models.Subject).count() > 0:
        return  # đã có dữ liệu rồi, không seed nữa

    # Subject 1: Ngôn ngữ - Gia đình & màu sắc
    lang = models.Subject(
        title="Ngôn ngữ",
        description="Từ vựng cơ bản cho bé: gia đình, màu sắc, đồ vật.",
        order_index=1,
    )
    math = models.Subject(
        title="Toán tư duy",
        description="Nhận biết số, so sánh, tư duy logic đơn giản.",
        order_index=2,
    )
    life = models.Subject(
        title="Kỹ năng sống",
        description="Thói quen tốt và an toàn cho bé trong cuộc sống hằng ngày.",
        order_index=3,
    )

    db.add_all([lang, math, life])
    db.flush()  # có id để gán cho lesson

    # Lessons for Ngôn ngữ
    lesson_family = models.Lesson(
        subject_id=lang.id,
        title="Gia đình của bé",
        description="Học về bố, mẹ, ông, bà và anh chị em.",
        order_index=1,
    )
    lesson_colors = models.Lesson(
        subject_id=lang.id,
        title="Màu sắc vui nhộn",
        description="Nhận biết 6 màu cơ bản qua đồ vật quen thuộc.",
        order_index=2,
    )

    # Lessons for Math
    lesson_numbers = models.Lesson(
        subject_id=math.id,
        title="Đếm số từ 1 đến 5",
        description="Đếm số lượng đồ vật đơn giản.",
        order_index=1,
    )
    lesson_compare = models.Lesson(
        subject_id=math.id,
        title="To - nhỏ",
        description="So sánh kích thước đồ vật.",
        order_index=2,
    )

    # Lessons for Life skills
    lesson_hygiene = models.Lesson(
        subject_id=life.id,
        title="Rửa tay sạch khuẩn",
        description="Học các bước rửa tay đúng cách.",
        order_index=1,
    )
    lesson_safety = models.Lesson(
        subject_id=life.id,
        title="Không đi theo người lạ",
        description="Bé học cách từ chối và tìm người lớn tin cậy.",
        order_index=2,
    )

    db.add_all(
        [
            lesson_family,
            lesson_colors,
            lesson_numbers,
            lesson_compare,
            lesson_hygiene,
            lesson_safety,
        ]
    )
    db.flush()

    # Activities cho từng lesson (demo)
    activities = [
        # Gia đình
        models.Activity(
            lesson_id=lesson_family.id,
            title="Video: Gia đình của bé",
            description="Video hoạt hình ngắn giới thiệu các thành viên trong gia đình.",
            activity_type="video",
            order_index=1,
            content_url="https://example.com/video/gia-dinh",
        ),
        models.Activity(
            lesson_id=lesson_family.id,
            title="Game: Chọn đúng người thân",
            description="Bé nghe lời gọi và chọn đúng nhân vật.",
            activity_type="game",
            order_index=2,
        ),
        # Màu sắc
        models.Activity(
            lesson_id=lesson_colors.id,
            title="Video: Các màu cơ bản",
            description="Video minh hoạ 6 màu cơ bản qua đồ vật.",
            activity_type="video",
            order_index=1,
        ),
        models.Activity(
            lesson_id=lesson_colors.id,
            title="Game: Tô màu đúng",
            description="Bé chọn đúng màu theo yêu cầu.",
            activity_type="game",
            order_index=2,
        ),
        # Numbers
        models.Activity(
            lesson_id=lesson_numbers.id,
            title="Game: Đếm số đồ vật",
            description="Bé đếm số quả táo và chọn đáp án đúng.",
            activity_type="game",
            order_index=1,
        ),
        # Compare
        models.Activity(
            lesson_id=lesson_compare.id,
            title="Game: Chọn đồ vật to hơn",
            description="Bé chọn đồ vật có kích thước lớn hơn.",
            activity_type="game",
            order_index=1,
        ),
        # Hygiene
        models.Activity(
            lesson_id=lesson_hygiene.id,
            title="Video: 6 bước rửa tay",
            description="Video hướng dẫn 6 bước rửa tay vui nhộn.",
            activity_type="video",
            order_index=1,
        ),
        # Safety
        models.Activity(
            lesson_id=lesson_safety.id,
            title="Story: Người lạ và bé",
            description="Câu chuyện tương tác về an toàn với người lạ.",
            activity_type="story",
            order_index=1,
        ),
    ]

    db.add_all(activities)
    db.commit()
